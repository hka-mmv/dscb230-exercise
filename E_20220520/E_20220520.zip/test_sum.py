def test_sum():
    assert sum([1, 2, 3]) == 6, "Summe sollte 6 ergeben."

if __name__ == "__main__":
    test_sum()
    print("Alle Prüfungen bestanden.")
