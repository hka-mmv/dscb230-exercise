def test_sum():
    assert sum([1, 2, 3]) == 6, "Summe sollte 6 ergeben."

def test_sum_tuple():
    # assert sum((1, 2, 3)) == 6, "Summe in Tupel sollte 6 ergeben."
    assert sum((1, 2, 2)) == 6, "Summe in Tupel sollte 6 ergeben."
    
if __name__ == "__main__":
    test_sum()
    test_sum_tuple()
    print("Alle Prüfungen bestanden.")
